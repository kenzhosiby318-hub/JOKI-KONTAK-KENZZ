BY JOKI KENZZ WEBSITE
1. Ekstrak file ZIP.
2. Pastikan index.html dan folder assets berada dalam satu folder.
3. Buka index.html untuk melihat website.
4. Untuk membuat website bisa diakses melalui link publik, upload seluruh isi folder ke layanan hosting statis.
Semua tombol order membuka WhatsApp admin 0882019099950 (format internasional 62882019099950).
Pembayaran dan pengecekan ketersediaan tetap dikonfirmasi oleh admin melalui WhatsApp.
